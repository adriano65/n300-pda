#!/bin/sh

case "$1" in
	change)
		echo "change" >> /tmp/log.log
		;;

	*)
		echo "usage ..." >> /tmp/log.log
		fi
esac
