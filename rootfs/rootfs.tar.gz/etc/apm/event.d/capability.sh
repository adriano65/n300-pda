#!/bin/sh

case "$1" in
	capability)
		echo "capability" >> /tmp/log.log
		;;

	*)
		echo "usage ... $0" >>/tmp/log.log
		fi
esac
