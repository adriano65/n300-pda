#!/bin/sh
#
HextoBin() {
case $1 in
	f)
		echo -n "1111"
		;;
	e)
		echo -n "1110"
		;;
	d)
		echo -n "1101"
		;;
	c)
		echo -n "1100"
		;;
	b)
		echo -n "1011"
		;;
	a)
		echo -n "1010"
		;;
	9)
		echo -n "1001"
		;;
	8)
		echo -n "1000"
		;;
	7)
		echo -n "0111"
		;;
	6)
		echo -n "0110"
		;;
	5)
		echo -n "0101"
		;;
	4)
		echo -n "0100"
		;;
	3)
		echo -n "0011"
		;;
	2)
		echo -n "0010"
		;;
	1)
		echo -n "0001"
		;;
	0)
		echo -n "0000"
		;;
esac
}
